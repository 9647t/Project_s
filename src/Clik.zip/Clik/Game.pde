class Game {
  ArrayList<Enemy> enemies;
  int score = 0;
  
  int lastSpawnTime = 0;
  int spawnInterval = 2000; // spawn every 2 seconds
  
  Game() {
    enemies = new ArrayList<Enemy>();
    enemies.add(spawnEnemy());
    
  }
  
  void update() {
    if (millis() - lastSpawnTime > spawnInterval) {
      enemies.add(spawnEnemy());
      lastSpawnTime = millis();
      if (spawnInterval > 500) {
        spawnInterval -= 100;
      }
    }
    
    for (Enemy e : enemies) {
      e.update();
      if (dist(e.x, e.y, width/2, height/2) < e.size/2) {
        noLoop();
        Gameover go = new Gameover();
        go.display();
      }
    }
  }
  
  void display() {
    for (Enemy e : enemies) {
      e.display();
    }
    fill(255);
    textSize(20);
    text("Score: " + score, 500, 30);
  }
  
  void mousePressed() {
    for (int i = enemies.size()-1; i >= 0; i--) {
      Enemy e = enemies.get(i);
      if (e.isClicked(mouseX, mouseY)) {
        enemies.remove(i);
        score++;
      }
    }
  }
  
  Enemy spawnEnemy() {
  float ex, ey;
  int edge = int(random(3)); // 0 = top, 1 = left, 2 = right

  if (edge == 0) { // top
    ex = random(width);
    ey = 0;
  } else if (edge == 1) { // left
    ex = 0;
    ey = random(height);
  } else { // right
    ex = width;
    ey = random(height);
  }

  // Randomly choose type
  int type = int(random(3));
  float speed;
  float size;
  color c;

  if (type == 0) {        // slow big enemy
    speed = random(0.5, 1.2);
    size = 50;
    c = color(255, 0, 0); // red
  } else if (type == 1) { // medium green enemy
    speed = random(1, 2);
    size = 30;
    c = color(0, 255, 0); // green
  } else {                 // fast small enemy
    speed = random(2, 3);
    size = 20;
    c = color(0, 0, 255); // blue
  }

  return new Enemy(ex, ey, speed, size, c);
}
