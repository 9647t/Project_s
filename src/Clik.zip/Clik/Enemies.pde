class Enemy {
  float x, y;
  float speed;
  float size;
  color c;

  Enemy(float startX, float startY) {
    x = startX;
    y = startY;

    // choose enemy type
    int type = int(random(3));

    if (type == 0) {        // big slow
      speed = 1;
      size = 50;
      c = color(100, 0, 0);
    } else if (type == 1) { // medium
      speed = 2;
      size = 30;
      c = color(0, 50, 0);
    } else {                // small fast
      speed = 3;
      size = 20;
      c = color(0, 0, 100);
    }
  }

  void update() {
    float dx = width/2 - x;
    float dy = height/2 - y;
    float angle = atan2(dy, dx);

    x += cos(angle) * speed;
    y += sin(angle) * speed;
  }

  void display() {
    fill(c);
    ellipse(x, y, size, size);
  }

  boolean isClicked(float mx, float my) {
    return dist(mx, my, x, y) < size/2;
  }
}
