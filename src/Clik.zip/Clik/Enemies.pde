class Enemy {
  float x, y;
  float speed;
  float size;
  color c; // store color

  Enemy(float startX, float startY, float moveSpeed, float s, color col) {
    x = startX;
    y = startY;
    speed = moveSpeed;
    size = s;
    c = col;
  }

  void update() {
    float dx = width/2 - x;
    float dy = height/2 - y;
    float angle = atan2(dy, dx);
    x += cos(angle) * speed;
    y += sin(angle) * speed;
  }

  void display() {
    fill(c);
    ellipse(x, y, size, size);
  }

  boolean isClicked(float mx, float my) {
    return dist(mx, my, x, y) < size/2;
  }
}
