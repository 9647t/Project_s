class StartScreen {
  Button startButton;
  
  StartScreen() {
    startButton = new Button(200, 150, 200, 60, "START");
  }
  
  void display() {
    fill(255);
    textAlign(CENTER, CENTER);
    textSize(32);
    text("Clik", width/2, 100);
    startButton.display();
  }
  
  boolean isStartClicked(float mx, float my) {
    return startButton.isClicked(mx, my);
  }
}
