Screen currentScreen;

void setup() {
  size(600, 400);
  textAlign(CENTER, CENTER);
  currentScreen = new StartScreen();
}

void draw() {
  currentScreen.display();
}

void mousePressed() {
  currentScreen.mousePressed();
}
