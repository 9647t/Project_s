// Start screen
class StartScreen extends Screen {
  Button startButton;

  StartScreen() {
    startButton = new Button(250, 220, 100, 50, "START");
  }

  void display() {
    background(200);
    textSize(40);
    fill(0);
    text("WS", width/2, 120);
    startButton.display();
  }

  void mousePressed() {
    if (startButton.isClicked()) {
      currentScreen = new GameScreen();
    }
  }
}

// Game screen
class GameScreen extends Screen {
  void display() {
    background(100);
    textSize(40);
    fill(0);
    text("", width/2, height/2);
  }

  void mousePressed() {
    // nothing for now
  }
}

// Minimal base screen class
class Screen {
  void display() {}
  void mousePressed() {}
}
