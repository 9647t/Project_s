class Button {
  float x, y, w, h;
  String label;

  Button(float x, float y, float w, float h, String label) {
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.label = label;
  }

  void display() {
    fill(200);
    rect(x, y, w, h);
    fill(0);
    textSize(20);
    text(label, x + w/2, y + h/2);
  }

  boolean isClicked() {
    return mouseX > x && mouseX < x + w &&
           mouseY > y && mouseY < y + h;
  }
}
